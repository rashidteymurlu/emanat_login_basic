Hello developers?)
Today, i introduce first app.
This is emanat's basic login screen app.
App is native. Writed by Kotlin Programming Language 
Used: 
1. if, else , else if etc.
2. multiscreen support
3. layouts
4. navigation component
5. Adobe xd
{ username = emanat@gmail.com }
{ password = emanat123 }