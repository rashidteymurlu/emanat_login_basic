package com.example.navigationwork

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.Navigation
import kotlinx.android.synthetic.main.fragment_home.*
import android.widget.Toast.makeText as makeText1

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        button.setOnClickListener {
            val username = username.text.toString()
            val password = password.text.toString()
            if (username.isNotEmpty()&&password.isNotEmpty()) {
                if (username == "emanat@gmail.com" && password == "emanat123"){
                    val action = HomeFragmentDirections.actionHomeFragmentToSecondFragment()
                    Navigation.findNavController(it).navigate(action)
                }else if(username != "emanat@gmail.com" && password != "emanat123"){
                    val action = HomeFragmentDirections.actionHomeFragmentToFinalFragment()
                    Navigation.findNavController(it).navigate(action)
                }
            }else{
                toastinstead.text = "This fields cannot be empty"
            }

        }
    }
}
